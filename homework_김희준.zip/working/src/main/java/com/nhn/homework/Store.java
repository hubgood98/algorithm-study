package com.nhn.homework;

public class Store extends Thread{
    private int obj = 5; // 현재 전시된 물건 개수
    private final int maxobj = 10; // 최대 물건 전시 가능 개수
    private int Enter = 0; //현재 입장인원
    private final int maxEnter = 5; // 최대 입장 가능 인원
    boolean buyable = false;

    public Store() {
        enter();
    }

    public synchronized void enter() {
        // 입장 제한 확인
        while (Enter > maxEnter) {
            try {
                System.out.println("입장 제한으로 대기 중...");
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Enter++;
        System.out.println("현재 입장 인원 수 " + Enter+"명");
    }

    public synchronized void exit() {
        if (Enter > 0) {
            Enter--;
            System.out.println("퇴장했습니다. 현재 남은 인원: " + Enter);
            notifyAll(); // 대기 중인 입장 대기자에게 알림
        } else {
            System.out.println("퇴장할 인원이 없습니다.");
        }
    }

    public synchronized void buy(String Name) {
        while (obj == 0) {
            try {
                System.out.println(Name + "님이 물건이 없어서 대기중입니다...");
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        obj--;
        System.out.println(Name + "님 물건 구매완료! 현재 남은 재고 : " + obj);
        notifyAll(); // 대기 중인 소비자에게 물건 구매 알림
    }

    public synchronized void sell() {
        if (obj > 0) {
            obj--;
            System.out.println("물건을 판매했습니다. 현재 물건 개수: " + obj);
            notify(); // 물건을 판매했으므로 생산자에게 알림
        } else {
            System.out.println("판매할 물건이 없습니다.");
        }
    }

    public synchronized void supply() {
        if (obj + 1 <= maxobj) {
            obj += 1;
            System.out.println("매장에 물건을 추가했습니다. 현재 물건 개수: " + obj);
            notifyAll(); // 대기 중인 모든 소비자에게 매장이 물건을 추가했음을 알림
        } else {
            System.out.println("매장에 추가할 수 있는 물건 개수를 초과했습니다.");
        }
    }
    
    public void setOtherConsumerBuying(boolean status) {
        this.buyable = status;
    }
    public int getEnter()
    {
        return Enter;
    }
    public int getMaxEnter() 
    {
        return maxEnter;
    }
    public int getobj() 
    {
        return obj;
    }
    public int getmaxobj() 
    {
        return maxobj;
    }
}